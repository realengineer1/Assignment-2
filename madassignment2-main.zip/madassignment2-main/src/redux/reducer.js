import cart from "./Cart/cartSlice";

const rootReducer = {
	cart: cart,
}

export default rootReducer