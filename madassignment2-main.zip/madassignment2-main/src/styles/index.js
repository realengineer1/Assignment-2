import ButtonsStyles from './Buttons.css'

const Styles = {
    ButtonsStyles,
};

export default Styles;